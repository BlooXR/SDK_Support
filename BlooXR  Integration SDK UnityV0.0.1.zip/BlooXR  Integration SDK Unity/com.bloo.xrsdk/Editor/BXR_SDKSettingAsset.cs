﻿/*******************************************************************************
Copyright © 2021-2022 Bloo Technology Co., Ltd.All rights reserved.
*******************************************************************************/

using UnityEngine;

public class BXR_SDKSettingAsset : ScriptableObject
{
    public bool ignoreSDKSetting = false;
}
